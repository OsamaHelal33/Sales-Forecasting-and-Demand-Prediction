

# Load model
model        = joblib.load("best_model.pkl")
scaler       = joblib.load("scaler.pkl")
features     = json.load(open("selected_features.json"))
scale_f      = ['dcoilwtico','transactions','sales_avg_7d','sales_avg_30d',
                'sales_lag_1','sales_lag_7','sales_lag_14','sales_lag_28',
                'sales_std_7d','sales_std_30d']
scaler_mean  = scaler.mean_
scaler_std   = scaler.scale_

# Page config
st.set_page_config(page_title="Sales Forecasting", layout="wide")

# Title
st.title(" Sales Forecasting Dashboard")
st.markdown("**Predict future sales using XGBoost model**")
st.divider()

# Model info
col1, col2, col3, col4 = st.columns(4)
col1.metric("Model",  "XGBoost")
col2.metric("MAE",    "59.05")
col3.metric("RMSE",   "231.23")
col4.metric("R²",     "0.9709")
st.divider()

# Input section
st.subheader(" Enter Store & Date Information")
col1, col2, col3 = st.columns(3)

with col1:
    store   = st.number_input("Store Number",  1,  54,  1)
    family  = st.number_input("Family Code",   0,  32,  0)
    cluster = st.number_input("Cluster",       1,  17, 13)
    promo   = st.selectbox("On Promotion?", [0, 1])

with col2:
    year    = st.number_input("Year",  2013, 2020, 2017)
    month   = st.number_input("Month",    1,   12,    8)
    day     = st.number_input("Day",      1,   31,   15)
    holiday = st.selectbox("Is Holiday?", [0, 1])

with col3:
    oil     = st.number_input("Oil Price ($)", 0.0, 150.0, 50.0)
    trans   = st.number_input("Transactions",  0.0, 10000.0, 1000.0)
    lag1    = st.number_input("Yesterday Sales (lag_1)", 0.0, 50000.0, 500.0)
    lag7    = st.number_input("Last Week Sales (lag_7)", 0.0, 50000.0, 500.0)

st.divider()

# Predict button
if st.button("Predict Sales", type="primary", use_container_width=True):
    try:
        dow = pd.Timestamp(int(year), int(month), int(day)).dayofweek
        weekend = 1 if dow >= 5 else 0

        input_data = {
            "store_nbr":   store,  "family_code": family,
            "onpromotion": promo,  "year":        year,
            "month":       month,  "day":         day,
            "dayofweek":   dow,    "weekend":     weekend,
            "dcoilwtico":  oil,    "transactions":trans,
            "is_holiday":  holiday,"cluster":     cluster,
            "sales_avg_7d":0.0,    "sales_avg_30d":0.0,
            "sales_lag_1": lag1,   "sales_lag_7":  lag7,
            "sales_lag_14":0.0,    "sales_lag_28":0.0,
            "sales_std_7d":0.0,    "sales_std_30d":0.0
        }

        df = pd.DataFrame([input_data])

        # Scale
        for i, col in enumerate(scale_f):
            if col in df.columns:
                df[col] = (df[col] - scaler_mean[i]) / scaler_std[i]

        pred = max(0, float(model.predict(df[features].values)[0]))

        st.success(f" Predicted Sales: **{pred:.2f} units**")
        st.metric("Prediction", f"{pred:.2f} units", delta="XGBoost Model")

        # Show input summary
        st.subheader(" Input Summary")
        st.dataframe(pd.DataFrame([input_data]))

    except Exception as e:
        st.error(f"Error: {e}")
